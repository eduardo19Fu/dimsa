package xyz.pangosoft.dimsa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DimsaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DimsaApplication.class, args);
	}

}
